//
//  ContentView.swift
//  IOSVisionSegmenter
//
//  Main screen: live camera preview, real-time detection overlay,
//  floating EN/IT toggle, and a tap-to-reveal object info card.
//

import SwiftUI
import AVFoundation
import UIKit

struct ContentView: View {
    @StateObject private var cameraManager = CameraManager()
    @StateObject private var visionProcessor = VisionProcessor()
    @EnvironmentObject var localization: LocalizationManager

    @State private var selectedObject: DetectedObject?
    @State private var selectedAt: Date = .distantPast

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color.black.ignoresSafeArea()

                switch cameraManager.status {
                case .notDetermined, .requesting:
                    requestingView

                case .denied:
                    deniedView

                case .authorized, .configured:
                    cameraView(in: geometry.size)
                }
            }
        }
        .onAppear {
            if cameraManager.status == .notDetermined {
                cameraManager.requestPermission()
            }
        }
    }

    // MARK: - Subviews

    private var requestingView: some View {
        VStack(spacing: 16) {
            ProgressView()
                .progressViewStyle(.circular)
                .tint(.white)
            Text(localization.localizedString("requesting_permission"))
                .foregroundColor(.white)
                .font(.system(size: 14, weight: .medium, design: .rounded))
        }
    }

    private var deniedView: some View {
        VStack(spacing: 24) {
            Image(systemName: "camera.fill")
                .font(.system(size: 64))
                .foregroundColor(.white.opacity(0.35))
            Text(localization.localizedString("no_camera_permission"))
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .font(.system(size: 16, weight: .medium, design: .rounded))
            Button(localization.localizedString("open_settings")) {
                if let url = URL(string: UIApplication.openSettingsURLString) {
                    UIApplication.shared.open(url)
                }
            }
            .padding(.horizontal, 24).padding(.vertical, 12)
            .background(Color(red: 0.039, green: 0.518, blue: 1.000), in: RoundedRectangle(cornerRadius: 12))
            .foregroundColor(.white)
            .font(.system(size: 15, weight: .semibold, design: .rounded))
        }
        .padding(32)
    }

    private func cameraView(in size: CGSize) -> some View {
        ZStack {
            // Camera preview
            CameraPreviewView(previewLayer: cameraManager.previewLayer)
                .frame(width: size.width, height: size.height)
                .onAppear {
                    cameraManager.configureSession()
                    cameraManager.startSession()
                    cameraManager.onFrame = { pixelBuffer in
                        visionProcessor.processFrame(pixelBuffer)
                    }
                }

            // Detection overlay
            DetectionOverlayView(
                detectedObjects: visionProcessor.detectedObjects,
                selectedObject: $selectedObject,
                localization: localization,
                screenSize: size
            )

            // Top controls
            VStack {
                HStack(spacing: 12) {
                    LanguageToggle(localization: localization)

                    Spacer()

                    // Detection count badge
                    if !visionProcessor.detectedObjects.isEmpty {
                        Text("\(visionProcessor.detectedObjects.count) \(localization.localizedString("objects_found"))")
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                            .foregroundColor(.white)
                            .padding(.horizontal, 12).padding(.vertical, 7)
                            .background(.ultraThinMaterial, in: Capsule())
                            .overlay(Capsule().stroke(Color.white.opacity(0.15), lineWidth: 1))
                    }

                    // Start / stop
                    Button {
                        if cameraManager.isRunning { cameraManager.stopSession() }
                        else { cameraManager.startSession() }
                    } label: {
                        Image(systemName: cameraManager.isRunning ? "stop.circle.fill" : "play.circle.fill")
                            .font(.system(size: 30))
                            .foregroundColor(.white)
                            .padding(6)
                            .background(.ultraThinMaterial, in: Circle())
                            .overlay(Circle().stroke(Color.white.opacity(0.15), lineWidth: 1))
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)

                Spacer()

                // Bottom hint or selected-object card
                bottomCard
                    .padding(.bottom, 40)
            }
        }
    }

    @ViewBuilder
    private var bottomCard: some View {
        if let selected = selectedObject, Date().timeIntervalSince(selectedAt) < 8 {
            SelectedObjectCard(object: selected, localization: localization)
                .transition(.scale.combined(with: .opacity))
        } else if visionProcessor.detectedObjects.isEmpty {
            Text(localization.localizedString("no_objects"))
                .font(.system(size: 13, weight: .medium, design: .rounded))
                .foregroundColor(.white.opacity(0.6))
                .padding(.horizontal, 16).padding(.vertical, 10)
                .background(.ultraThinMaterial, in: Capsule())
        } else {
            Text(localization.localizedString("tap_object"))
                .font(.system(size: 13, weight: .medium, design: .rounded))
                .foregroundColor(.white.opacity(0.85))
                .padding(.horizontal, 16).padding(.vertical, 10)
                .background(.ultraThinMaterial, in: Capsule())
        }
    }
}

// MARK: - Language toggle

struct LanguageToggle: View {
    @ObservedObject var localization: LocalizationManager

    var body: some View {
        Button {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                localization.currentLanguage = localization.currentLanguage.other
            }
            UISelectionFeedbackGenerator().selectionChanged()
        } label: {
            HStack(spacing: 6) {
                Text(localization.currentLanguage.flag)
                    .font(.system(size: 12, weight: .heavy, design: .rounded))
                    .foregroundColor(.white)
                Image(systemName: "arrow.triangle.2.circlepath")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundColor(.white.opacity(0.7))
            }
            .padding(.horizontal, 14).padding(.vertical, 8)
            .background(.ultraThinMaterial, in: Capsule())
            .overlay(Capsule().stroke(Color.white.opacity(0.15), lineWidth: 1))
        }
    }
}

// MARK: - Camera preview bridge

struct CameraPreviewView: UIViewRepresentable {
    let previewLayer: AVCaptureVideoPreviewLayer?

    func makeUIView(context: Context) -> UIView {
        let v = UIView()
        v.backgroundColor = .black
        return v
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        guard let layer = previewLayer else { return }
        layer.frame = uiView.bounds
        if layer.superlayer == nil {
            uiView.layer.addSublayer(layer)
        }
        uiView.backgroundColor = .black
    }
}

// MARK: - Detection overlay

struct DetectionOverlayView: View {
    let detectedObjects: [DetectedObject]
    @Binding var selectedObject: DetectedObject?
    let localization: LocalizationManager
    let screenSize: CGSize

    var body: some View {
        ZStack {
            ForEach(detectedObjects) { object in
                let rect = visionRectToView(object.boundingBox, in: screenSize)

                // Animated dashed border
                RoundedRectangle(cornerRadius: 10)
                    .stroke(object.color, style: StrokeStyle(lineWidth: 3))
                    .frame(width: rect.width, height: rect.height)
                    .position(x: rect.midX, y: rect.midY)
                    .shadow(color: object.color.opacity(0.7), radius: 10)
                    .animation(.easeInOut(duration: 0.2), value: detectedObjects.count)

                // Corner ticks for a "scanner" feel
                CornerTicks(color: object.color, length: 14, thickness: 3)
                    .frame(width: rect.width, height: rect.height)
                    .position(x: rect.midX, y: rect.midY)

                // Tap zone
                Color.clear
                    .contentShape(Rectangle())
                    .frame(width: rect.width, height: rect.height)
                    .position(x: rect.midX, y: rect.midY)
                    .onTapGesture {
                        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.7)) {
                            selectedObject = object
                        }
                    }
            }
        }
        .allowsHitTesting(true)
    }

    /// Vision uses normalized coordinates with origin at bottom-left and
    /// Y growing upward. SwiftUI uses top-left origin with Y growing downward.
    private func visionRectToView(_ rect: CGRect, in size: CGSize) -> CGRect {
        let x = rect.origin.x * size.width
        let y = (1 - rect.origin.y - rect.height) * size.height
        let w = rect.width * size.width
        let h = rect.height * size.height
        return CGRect(x: x, y: y, width: w, height: h)
    }
}

/// Four small L-shaped ticks at the corners of the bounding box.
struct CornerTicks: View {
    let color: Color
    let length: CGFloat
    let thickness: CGFloat

    var body: some View {
        GeometryReader { geo in
            Canvas { ctx, size in
                // Top-left
                ctx.fill(Path { p in
                    p.move(to: CGPoint(x: 0, y: length))
                    p.addLine(to: CGPoint(x: 0, y: 0))
                    p.addLine(to: CGPoint(x: length, y: 0))
                    p.addLine(to: CGPoint(x: thickness, y: 0))
                    p.addLine(to: CGPoint(x: thickness, y: length - thickness))
                    p.addLine(to: CGPoint(x: length, y: length - thickness))
                    p.addLine(to: CGPoint(x: length, y: thickness))
                    p.closeSubpath()
                }, with: .color(color))
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
    }
}

// MARK: - Selected object card

struct SelectedObjectCard: View {
    let object: DetectedObject
    let localization: LocalizationManager

    var body: some View {
        HStack(spacing: 14) {
            // Category icon
            ZStack {
                Circle()
                    .fill(object.color.opacity(0.2))
                    .frame(width: 44, height: 44)
                Image(systemName: categoryIcon)
                    .foregroundColor(object.color)
                    .font(.system(size: 18, weight: .semibold))
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(localization.translate(object.label))
                    .font(.system(size: 19, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                Text("\(localization.localizedString("confidence")) · \(Int(object.confidence * 100))%")
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundColor(.white.opacity(0.65))
            }

            Spacer()

            // Color chip
            RoundedRectangle(cornerRadius: 4)
                .fill(object.color)
                .frame(width: 6, height: 36)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 14)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18))
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(object.color.opacity(0.5), lineWidth: 1.5)
        )
        .shadow(color: object.color.opacity(0.3), radius: 20)
        .padding(.horizontal, 24)
    }

    private var categoryIcon: String {
        switch object.category {
        case .person:      return "person.fill"
        case .animal:      return "pawprint.fill"
        case .food:        return "fork.knife"
        case .vehicle:     return "car.fill"
        case .household:   return "house.fill"
        case .electronics: return "laptopcomputer"
        case .clothing:    return "tshirt.fill"
        case .plant:       return "leaf.fill"
        case .other:       return "questionmark"
        }
    }
}
