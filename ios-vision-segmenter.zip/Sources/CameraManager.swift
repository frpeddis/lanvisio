//
//  CameraManager.swift
//  IOSVisionSegmenter
//
//  Manages the AVCaptureSession, output sample buffers, and permissions.
//  All session configuration happens on a dedicated serial queue to keep
//  the main thread free for UI rendering.
//

import AVFoundation
import Combine
import UIKit

@MainActor
final class CameraManager: NSObject, ObservableObject {
    enum Status: Equatable {
        case notDetermined
        case requesting
        case authorized
        case denied
        case configured
    }

    @Published var status: Status = .notDetermined
    @Published var isRunning = false
    @Published var previewLayer: AVCaptureVideoPreviewLayer?

    /// Called on every new video frame. The handler is responsible for
    /// throttling if it cannot process at full frame rate.
    var onFrame: ((CVPixelBuffer) -> Void)?

    private let session = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private let sessionQueue = DispatchQueue(label: "io.vision.camera.session", qos: .userInitiated)
    private var isConfigured = false

    override init() {
        super.init()
        let raw = AVCaptureDevice.authorizationStatus(for: .video)
        switch raw {
        case .authorized:   status = .authorized
        case .denied:       status = .denied
        case .notDetermined: status = .notDetermined
        case .restricted:   status = .denied
        @unknown default:   status = .notDetermined
        }
    }

    func requestPermission() {
        status = .requesting
        AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
            Task { @MainActor in
                self?.status = granted ? .authorized : .denied
            }
        }
    }

    func configureSession() {
        guard !isConfigured else { return }
        isConfigured = true

        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            self.session.beginConfiguration()
            self.session.sessionPreset = .high

            // Prefer the triple-camera on newer iPhones, fall back to wide.
            let device = AVCaptureDevice.default(.builtInTripleCamera,  for: .video, position: .back)
                ?? AVCaptureDevice.default(.builtInDualCamera,          for: .video, position: .back)
                ?? AVCaptureDevice.default(.builtInWideAngleCamera,     for: .video, position: .back)

            guard let camera = device,
                  let input = try? AVCaptureDeviceInput(device: camera),
                  self.session.canAddInput(input) else {
                self.session.commitConfiguration()
                return
            }
            self.session.addInput(input)

            self.videoOutput.setSampleBufferDelegate(self, queue: self.sessionQueue)
            self.videoOutput.videoSettings = [
                kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA
            ]
            self.videoOutput.alwaysDiscardsLateVideoFrames = true

            if self.session.canAddOutput(self.videoOutput) {
                self.session.addOutput(self.videoOutput)
                if let connection = self.videoOutput.connection(with: .video) {
                    connection.videoOrientation = .portrait
                    if connection.isVideoMirroringSupported {
                        connection.isVideoMirrored = false
                    }
                }
            }

            self.session.commitConfiguration()

            let preview = AVCaptureVideoPreviewLayer(session: self.session)
            preview.videoGravity = .resizeAspectFill
            preview.connection?.videoOrientation = .portrait

            Task { @MainActor in
                self.previewLayer = preview
                self.status = .configured
            }
        }
    }

    func startSession() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            if !self.session.isRunning {
                self.session.startRunning()
                Task { @MainActor in self.isRunning = true }
            }
        }
    }

    func stopSession() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            if self.session.isRunning {
                self.session.stopRunning()
                Task { @MainActor in self.isRunning = false }
            }
        }
    }
}

extension CameraManager: AVCaptureVideoDataOutputSampleBufferDelegate {
    nonisolated func captureOutput(
        _ output: AVCaptureOutput,
        didOutput sampleBuffer: CMSampleBuffer,
        from connection: AVCaptureConnection
    ) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        // Bridge the pixelBuffer to the main-actor onFrame closure.
        let buffer = pixelBuffer
        Task { @MainActor [weak self] in
            self?.onFrame?(buffer)
        }
    }
}
