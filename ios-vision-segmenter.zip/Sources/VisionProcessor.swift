//
//  VisionProcessor.swift
//  IOSVisionSegmenter
//
//  Runs two Vision requests per analyzed frame:
//    1. VNGenerateAttentionBasedSaliencyImageRequest — locates the most
//       visually salient object(s) and returns bounding boxes.
//    2. VNClassifyImageRequest — returns ImageNet class labels with
//       confidence scores for the whole frame.
//
//  The two are merged: each salient region gets the top matching label.
//  Processing is throttled to ~10 Hz so the UI stays smooth even on
//  older devices.
//

import Vision
import CoreImage
import Combine
import UIKit

struct DetectedObject: Identifiable, Equatable {
    let id = UUID()
    let boundingBox: CGRect      // Normalized Vision coords (origin bottom-left)
    let label: String            // Raw ImageNet label
    let confidence: Float
    let color: UIColor
    let category: ObjectCategory

    static func == (lhs: DetectedObject, rhs: DetectedObject) -> Bool { lhs.id == rhs.id }
}

enum ObjectCategory: String {
    case person, animal, food, vehicle, household, electronics, clothing, plant, other

    static func from(label: String) -> ObjectCategory {
        let l = label.lowercased()
        if l.contains("dog") || l.contains("cat") || l.contains("bird") || l.contains("horse")
            || l.contains("elephant") || l.contains("zebra") || l.contains("bear")
            || l.contains("cow") || l.contains("sheep") || l.contains("rabbit")
            || l.contains("monkey") || l.contains("hamster") || l.contains("squirrel")
            || l.contains("fox") || l.contains("lion") || l.contains("tiger") {
            return .animal
        }
        if l.contains("pizza") || l.contains("spaghetti") || l.contains("espresso")
            || l.contains("coffee") || l.contains("cheese") || l.contains("wine")
            || l.contains("banana") || l.contains("apple") || l.contains("orange")
            || l.contains("lemon") || l.contains("strawberry") || l.contains("bread")
            || l.contains("burrito") || l.contains("hotdog") || l.contains("soup")
            || l.contains("ice cream") || l.contains("cake") || l.contains("cookie")
            || l.contains("egg") || l.contains("meat") || l.contains("salad") {
            return .food
        }
        if l.contains("car") || l.contains("truck") || l.contains("bicycle")
            || l.contains("motorcycle") || l.contains("bus") || l.contains("train")
            || l.contains("airplane") || l.contains("boat") || l.contains("ship")
            || l.contains("vehicle") || l.contains("scooter") {
            return .vehicle
        }
        if l.contains("table") || l.contains("chair") || l.contains("sofa")
            || l.contains("couch") || l.contains("desk") || l.contains("bed")
            || l.contains("lamp") || l.contains("shelf") || l.contains("wardrobe")
            || l.contains("cabinet") || l.contains("pillow") || l.contains("mirror") {
            return .household
        }
        if l.contains("laptop") || l.contains("computer") || l.contains("phone")
            || l.contains("keyboard") || l.contains("mouse") || l.contains("monitor")
            || l.contains("television") || l.contains("camera") || l.contains("speaker")
            || l.contains("headphone") || l.contains("tablet") {
            return .electronics
        }
        if l.contains("shirt") || l.contains("jacket") || l.contains("coat")
            || l.contains("dress") || l.contains("pants") || l.contains("shoe")
            || l.contains("boot") || l.contains("hat") || l.contains("helmet")
            || l.contains("tie") || l.contains("glove") {
            return .clothing
        }
        if l.contains("flower") || l.contains("tree") || l.contains("leaf")
            || l.contains("plant") || l.contains("grass") || l.contains("daisy")
            || l.contains("rose") || l.contains("orchid") || l.contains("mushroom") {
            return .plant
        }
        if l.contains("person") || l.contains("man") || l.contains("woman")
            || l.contains("boy") || l.contains("girl") {
            return .person
        }
        return .other
    }

    var color: UIColor {
        switch self {
        case .person:     return UIColor(red: 1.000, green: 0.271, blue: 0.227, alpha: 1.0)  // #FF453A red
        case .animal:     return UIColor(red: 0.298, green: 0.886, blue: 0.404, alpha: 1.0)  // #30D158 green
        case .food:       return UIColor(red: 1.000, green: 0.620, blue: 0.039, alpha: 1.0)  // #FF9F0A orange
        case .vehicle:    return UIColor(red: 0.039, green: 0.518, blue: 1.000, alpha: 1.0)  // #0A84FF blue
        case .household:  return UIColor(red: 0.749, green: 0.353, blue: 0.949, alpha: 1.0)  // #BF5AF2 purple
        case .electronics:return UIColor(red: 0.392, green: 0.871, blue: 1.000, alpha: 1.0)  // #64D2FF cyan
        case .clothing:   return UIColor(red: 1.000, green: 0.435, blue: 0.812, alpha: 1.0)  // #FF6FED pink
        case .plant:      return UIColor(red: 0.451, green: 0.992, blue: 0.467, alpha: 1.0)  // #73FDP light green
        case .other:      return UIColor(red: 1.000, green: 0.839, blue: 0.039, alpha: 1.0)  // #FFD60A yellow
        }
    }
}

@MainActor
final class VisionProcessor: ObservableObject {
    @Published var detectedObjects: [DetectedObject] = []

    private var lastProcessTime: CFTimeInterval = 0
    private let processInterval: CFTimeInterval = 0.1   // 10 Hz analysis
    private let minConfidence: Float = 0.20

    func processFrame(_ pixelBuffer: CVPixelBuffer, orientation: CGImagePropertyOrientation = .up) {
        let now = CACurrentMediaTime()
        guard now - lastProcessTime > processInterval else { return }
        lastProcessTime = now

        // Detach from MainActor — Vision work is heavy.
        Task.detached(priority: .userInitiated) { [weak self] in
            guard let self = self else { return }

            let classifications = await self.runClassification(on: pixelBuffer, orientation: orientation)
            let salientBoxes   = await self.runSaliency(on: pixelBuffer, orientation: orientation)

            await self.buildObjects(classifications: classifications, salientBoxes: salientBoxes)
        }
    }

    // MARK: - Vision requests

    private func runClassification(
        on pixelBuffer: CVPixelBuffer,
        orientation: CGImagePropertyOrientation
    ) async -> [VNClassificationObservation] {
        await withCheckedContinuation { continuation in
            let request = VNClassifyImageRequest { request, _ in
                let results = (request.results as? [VNClassificationObservation]) ?? []
                continuation.resume(returning: results)
            }
            do {
                try VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: orientation)
                    .perform([request])
            } catch {
                continuation.resume(returning: [])
            }
        }
    }

    private func runSaliency(
        on pixelBuffer: CVPixelBuffer,
        orientation: CGImagePropertyOrientation
    ) async -> [CGRect] {
        await withCheckedContinuation { continuation in
            let request = VNGenerateAttentionBasedSaliencyImageRequest { request, _ in
                guard let observation = request.results?.first as? VNSaliencyImageObservation,
                      let salientObjects = observation.salientObjects, !salientObjects.isEmpty else {
                    continuation.resume(returning: [])
                    return
                }
                let boxes = salientObjects.map { $0.boundingBox }
                continuation.resume(returning: boxes)
            }
            request.revision = VNGenerateAttentionBasedSaliencyImageRequestRevision1
            do {
                try VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: orientation)
                    .perform([request])
            } catch {
                continuation.resume(returning: [])
            }
        }
    }

    // MARK: - Merge into DetectedObject list

    private func buildObjects(
        classifications: [VNClassificationObservation],
        salientBoxes: [CGRect]
    ) async {
        let topLabels = classifications
            .filter { $0.confidence >= minConfidence }
            .prefix(3)
            .map { ($0.identifier.replacingOccurrences(of: "_", with: " "), $0.confidence) }

        var objects: [DetectedObject] = []

        if salientBoxes.isEmpty {
            // No saliency — show a single full-frame object using the top label.
            if let top = topLabels.first {
                let category = ObjectCategory.from(label: top.0)
                objects.append(DetectedObject(
                    boundingBox: CGRect(x: 0.20, y: 0.20, width: 0.60, height: 0.60),
                    label: top.0,
                    confidence: top.1,
                    color: category.color,
                    category: category
                ))
            }
        } else {
            for (index, box) in salientBoxes.prefix(3).enumerated() {
                let label = topLabels[index % max(topLabels.count, 1)].0
                let conf  = topLabels[index % max(topLabels.count, 1)].1
                let category = ObjectCategory.from(label: label)
                objects.append(DetectedObject(
                    boundingBox: box,
                    label: label,
                    confidence: conf,
                    color: category.color,
                    category: category
                ))
            }
        }

        await MainActor.run { [weak self] in
            self?.detectedObjects = objects
        }
    }
}
