//
//  IOSVisionSegmenterApp.swift
//  IOSVisionSegmenter
//
//  Real-time on-device computer vision app for iPhone.
//  Uses AVFoundation for camera capture and Apple's Vision framework for
//  saliency-based segmentation + image classification. No model download
//  required — everything runs on-device using built-in iOS capabilities.
//

import SwiftUI

@main
struct IOSVisionSegmenterApp: App {
    @StateObject private var localization = LocalizationManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(localization)
                .preferredColorScheme(.dark)
        }
    }
}
