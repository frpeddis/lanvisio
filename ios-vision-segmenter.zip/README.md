# IOSVisionSegmenter

Real-time on-device computer vision for iPhone. Point the camera at the world, the app highlights visually salient objects with a colored border, and tapping any highlighted object reveals its name and confidence. Toggle between **English 🇬🇧** and **Italiano 🇮🇹** on the fly with a single tap.

Built entirely with **SwiftUI + AVFoundation + Apple's Vision framework** — no third-party libraries, no model downloads, no internet required. Everything runs on-device.

---

## Features

| Feature | Implementation |
|---|---|
| Real-time camera preview | `AVCaptureSession` on a background queue, 30 FPS capture, 10 Hz analysis |
| Object segmentation | `VNGenerateAttentionBasedSaliencyImageRequest` finds salient objects |
| Object recognition | `VNClassifyImageRequest` returns ImageNet class labels |
| Colored borders | Each object is bordered with a color based on its category (person, animal, food, vehicle, household, electronics, clothing, plant, other) |
| Tap to identify | Tap any highlighted object → name + confidence appear in a glass card |
| EN / IT language toggle | Floating button top-left, switches instantly, choice persisted |
| Haptic feedback | Medium impact on tap, selection feedback on language switch |
| Modern dark UI | Glassmorphism panels, neon accents (#0A84FF / #BF5AF2), SF Symbols |
| Permission handling | Clean denied / requesting / authorized states |

---

## Requirements

- **macOS 14+** with **Xcode 15+** (download free from the Mac App Store)
- **iPhone** running **iOS 16+** (Vision saliency request requires iOS 13+, classify request requires iOS 13+)
- An Apple ID (free) for code signing — you do **not** need a paid developer account to run on your own iPhone
- A [GitHub](https://github.com) account

---

## Project structure

```
ios-vision-segmenter/
├── README.md                       ← You are here
├── LICENSE                         ← MIT
├── .gitignore                      ← Xcode-aware ignore list
└── Sources/
    ├── IOSVisionSegmenterApp.swift ← App entry point
    ├── ContentView.swift           ← Main screen (camera + overlay + controls)
    ├── CameraManager.swift         ← AVCaptureSession + permissions
    ├── VisionProcessor.swift       ← Saliency + classification + merging
    ├── LocalizationManager.swift   ← EN/IT toggle + ImageNet label translations
    └── Info.plist                  ← NSCameraUsageDescription + app config
```

---

# Part A — Create the Xcode project locally

> Estimated time: 10 minutes. You only do this once.

### A1. Move the source files somewhere convenient

Download / copy the entire `ios-vision-segmenter/` folder to your Mac, e.g. to `~/Developer/ios-vision-segmenter/`.

```bash
# From Terminal on your Mac
mv ~/Downloads/ios-vision-segmenter ~/Developer/
cd ~/Developer/ios-vision-segmenter
```

### A2. Create a new Xcode project

1. Open **Xcode** → **File → New → Project…** (`⇧⌘N`)
2. Select **iOS → App**, click **Next**
3. Fill in:
   - **Product Name:** `IOSVisionSegmenter` *(exact, case-sensitive)*
   - **Team:** your Apple ID (sign in if needed — Xcode will guide you)
   - **Organization Identifier:** e.g. `com.yourname`
   - **Interface:** `SwiftUI`
   - **Language:** `Swift`
   - **Storage:** `None`
   - **Include Tests:** uncheck both
4. Click **Next**
5. **Save location:** choose your `~/Developer/ios-vision-segmenter/` folder
6. **IMPORTANT:** when Xcode asks "An item named 'IOSVisionSegmenter' already exists in this location" — choose **"Add to existing folder / Keep both"** so you don't lose the source files. Then **delete** the auto-generated `ContentView.swift` and `IOSVisionSegmenterApp.swift` from the Xcode navigator (right-click → Delete → Move to Trash).

### A3. Add the pre-written source files to the project

1. In Xcode's Project Navigator (left sidebar), right-click the `IOSVisionSegmenter` group → **Add Files to "IOSVisionSegmenter"…**
2. Navigate to `~/Developer/ios-vision-segmenter/Sources/`
3. Select **all five Swift files** + `Info.plist`:
   - `IOSVisionSegmenterApp.swift`
   - `ContentView.swift`
   - `CameraManager.swift`
   - `VisionProcessor.swift`
   - `LocalizationManager.swift`
   - `Info.plist`
4. Before clicking **Add**, make sure:
   - ✅ **Copy items if needed** is unchecked (they're already in the right place)
   - ✅ **Create groups** is selected (not "Create folder references")
   - ✅ **Add to targets: IOSVisionSegmenter** is checked
5. Click **Add**

### A4. Configure the Info.plist (camera permission)

Xcode 15 manages permissions in the target's **Info** tab — no need to edit the plist file directly.

1. Click the **IOSVisionSegmenter** project at the top of the navigator → select the **IOSVisionSegmenter** target → **Info** tab
2. Under **Custom iOS Target Properties**, find the row **"Privacy - Camera Usage Description"** (if it's not there, the `Info.plist` you added already declares it — Xcode will pick it up automatically).
3. Verify the value is:
   > `IOSVisionSegmenter needs camera access to perform real-time object segmentation and recognition on the live video feed.`

### A5. Build & run on your iPhone

1. Plug your iPhone into your Mac with a USB cable (or use Wi-Fi debugging after first USB pairing)
2. Trust the computer on the iPhone if prompted
3. In Xcode, select your iPhone in the **device dropdown** at the top of the window (next to the play button)
4. Click the **▶ Run** button (`⌘R`) — Xcode builds, installs, and launches the app
5. First launch: iOS will ask for camera permission → tap **Allow**
6. Point the camera at objects — you'll see colored borders appear around salient objects
7. Tap a highlighted object → a glass card with the object's name (EN or IT depending on your toggle) slides in
8. Tap the **EN ⇄ IT** button top-left to switch languages instantly

> **If you hit a code-signing error**: open **Settings → General → VPN & Device Management** on the iPhone → tap your Apple ID → **Trust**. Then re-run from Xcode.

---

# Part B — Push the project to GitHub

> Estimated time: 5 minutes. You only do this once.

### B1. Create an empty repository on GitHub

1. Go to <https://github.com/new>
2. **Repository name:** `ios-vision-segmenter` (or whatever you prefer)
3. **Description:** `Real-time on-device object segmentation & recognition for iPhone — SwiftUI + Vision framework`
4. Choose **Public** or **Private** (your call)
5. **DO NOT** check "Add a README file" — we already have one
6. **DO NOT** add `.gitignore` or license from the web UI — we already have both
7. Click **Create repository**

GitHub will show you a page with clone URLs. **Leave it open** — you'll need the URL in step B3.

### B2. Initialize git locally (if not already done by Xcode)

Xcode usually initializes git when you create a project. If you don't see a `.git` folder in your project directory, initialize it:

```bash
cd ~/Developer/ios-vision-segmenter

# Initialize git (skip if Xcode already created .git/)
git init

# Stage everything (the .gitignore file we shipped will keep build artifacts out)
git add .

# Verify what's about to be committed — no build/, no DerivedData/, no .xcuserstate
git status

# Make the first commit
git commit -m "Initial commit: real-time iOS Vision segmenter with EN/IT toggle"
```

### B3. Add the GitHub remote and push

Copy your repository URL from the GitHub page. It will look like one of:

- HTTPS: `https://github.com/YOUR_USERNAME/ios-vision-segmenter.git`
- SSH: `git@github.com:YOUR_USERNAME/ios-vision-segmenter.git` (recommended if you have SSH keys set up)

Then in Terminal:

```bash
# Replace YOUR_USERNAME and the URL with your actual repo URL
git remote add origin https://github.com/YOUR_USERNAME/ios-vision-segmenter.git

# Rename the default branch to 'main' (modern convention)
git branch -M main

# Push to GitHub
git push -u origin main
```

### B4. Authenticate when prompted

- **HTTPS:** GitHub will pop up a "Sign in to GitHub" window (or a credential prompt in Terminal). Sign in with your browser. If you have 2FA enabled (recommended), GitHub requires a **Personal Access Token** instead of your password:
  1. Go to <https://github.com/settings/tokens?type=beta> (fine-grained tokens, recommended)
  2. Click **Generate new token**
  3. **Repository access:** only the `ios-vision-segmenter` repo
  4. **Permissions → Repository permissions → Contents:** `Read and write`
  5. Click **Generate token** → copy the token
  6. When Terminal asks for your password, paste the token instead
- **SSH:** no password prompt — it uses your SSH key. If you see "Permission denied (publickey)", see <https://docs.github.com/ssh>.

### B5. Verify

Open `https://github.com/YOUR_USERNAME/ios-vision-segmenter` in your browser — you should see the README rendered, with all source files under `Sources/`. The repo now has a green **Code** button you can share with anyone.

---

# Part C — Future commits (workflow)

After making changes in Xcode, push them:

```bash
cd ~/Developer/ios-vision-segmenter

# See what changed
git status
git diff

# Stage and commit
git add .
git commit -m "Describe your change here"
git push
```

If you want to use Xcode's built-in git UI instead of the terminal:
- **⌃⌘C** to commit
- **Source Control → Push…** to push

---

# Architecture overview

```
┌─────────────────────────────────────────────────────────────────┐
│ ContentView.swift (SwiftUI, main thread)                         │
│  - CameraPreviewView (UIViewRepresentable wrapping previewLayer) │
│  - DetectionOverlayView (ZStack of borders + tap zones)          │
│  - Top bar: LanguageToggle + detection count + start/stop        │
│  - Bottom card: SelectedObjectCard or hint                       │
└───────────────▲───────────────────────────────────┬─────────────┘
                │ pixelBuffer                        │ detectedObjects
                │                                    ▼
┌───────────────┴──────────────────┐   ┌──────────────────────────┐
│ CameraManager.swift (MainActor)   │   │ VisionProcessor.swift    │
│  - AVCaptureSession (queue)       │   │  (MainActor + Task.det.) │
│  - AVCaptureVideoDataOutput       │   │  - VNClassifyImage       │
│  - onFrame callback → 10Hz throttle │ │  - VNSaliency (attn.)    │
└───────────────────────────────────┘   │  - merges → DetectedObject│
                                        └──────────────────────────┘
                       ▲
                       │ translate(label), localizedString(key)
                       │
                  ┌────┴────────────────────────┐
                  │ LocalizationManager.swift    │
                  │  - currentLanguage: en | it  │
                  │  - persisted to UserDefaults │
                  │  - 200+ ImageNet→IT labels   │
                  └──────────────────────────────┘
```

### Why two Vision requests?

`VNClassifyImageRequest` only tells you **what** is in the frame — not **where**. `VNGenerateAttentionBasedSaliencyImageRequest` tells you **where** the most visually salient object(s) are but not **what** they are. Combining them gives us both.

If you later want true per-object classification (not just whole-frame label applied to salient regions), the natural upgrade path is to bundle a Core ML model like **YOLOv8-seg** (already in Core ML format) and use `VNCoreMLRequest`. That gives you pixel-accurate masks per object with per-object labels in a single request.

---

# Customization tips

| You want to change… | Look at… |
|---|---|
| Color of borders per category | `ObjectCategory.color` in `VisionProcessor.swift` |
| Analysis frame rate | `processInterval` in `VisionProcessor.swift` |
| Confidence threshold | `minConfidence` in `VisionProcessor.swift` |
| Add Italian labels for new ImageNet classes | `translations` dict in `LocalizationManager.swift` |
| UI accent colors / typography | `ContentView.swift` |
| Camera quality preset | `session.sessionPreset = .high` in `CameraManager.swift` (try `.hd1280x720` for smoother, `.hd4K3840x2160` for sharper) |

---

# Troubleshooting

**"Thread Performance Checker: SIGART at launch"**
Make sure your iPhone runs iOS 16 or newer. The Vision requests used require iOS 13+, but the SwiftUI APIs (e.g. `.background(.ultraThinMaterial, in:)`) require iOS 15+.

**Camera shows black screen**
Open iPhone Settings → IOSVisionSegmenter → enable Camera. Force-quit and relaunch.

**No borders appearing**
Saliency detection works best on high-contrast scenes with a clear subject. Try pointing at a single object against a contrasting background (a cup on a white table, a person against a wall). The built-in saliency detector is conservative — it only highlights strongly salient regions.

**Label says something wrong**
`VNClassifyImageRequest` uses an ImageNet-trained model, which is 1000 classes and not always accurate on out-of-distribution objects. For better accuracy, swap in a YOLOv8-seg Core ML model.

**Italian label missing (shows English)**
The `translations` dictionary in `LocalizationManager.swift` covers ~250 common classes. Add the missing label there. The raw ImageNet identifier is shown in English as a fallback.

**GitHub push fails with "Authentication failed"**
Generate a personal access token (B4 above) and paste it as the password. Your GitHub account password will NOT work over HTTPS.

---

# License

MIT — see [LICENSE](LICENSE). You're free to fork, modify, and ship.

---

# Acknowledgements

- Apple Vision framework docs: <https://developer.apple.com/documentation/vision>
- ImageNet class index used by `VNClassifyImageRequest`
- SwiftUI glassmorphism pattern using `.ultraThinMaterial`
