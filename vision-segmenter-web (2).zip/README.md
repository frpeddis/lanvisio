# Vision Segmenter (Web)

Single-file web app: real-time object detection in your browser using TensorFlow.js + COCO-SSD. Works in iPhone Safari and can be added to the home screen as a PWA.

## Quick start (easiest)

1. Download `index.html` to your Mac
2. **Option A — just open it:** double-click `index.html` → opens in your default browser. Camera works in Chrome / Firefox / Edge. (Safari requires HTTPS or localhost — see Option B.)
3. **Option B — run from a local server (recommended for Safari/iPhone):**

```bash
# In Terminal, go to the folder containing index.html
cd ~/Downloads/vision-segmenter-web   # or wherever you unzipped it

# Start a tiny local server (Python 3 is preinstalled on macOS)
python3 -m http.server 8000
```

Then on your iPhone:
- Make sure iPhone and Mac are on the **same Wi-Fi network**
- Find your Mac's local IP: `System Settings → Wi-Fi → Details… → IP address` (looks like `192.168.1.something`)
- On iPhone Safari, open: `http://192.168.1.XXX:8000/`
- Safari will ask for camera permission → **Allow**
- Tap **Share → Add to Home Screen** to install it as an app

## Features

- Real-time object detection (~10–15 fps on iPhone)
- 80 COCO classes (person, car, dog, cup, laptop, etc.)
- Color-coded borders by category (red=person, blue=vehicle, green=animal, orange=food, etc.)
- Tap any highlighted object → name + confidence card slides up
- Floating EN ⇄ IT language toggle (top-left)
- Modern dark glassmorphism UI
- Haptic feedback on tap (where supported)
- 100% client-side — no data leaves your device

## Deploy to the web (free, optional)

Want a public URL to share? Push `index.html` to any static host:

### GitHub Pages
1. Create a public repo on GitHub
2. Upload `index.html` to the repo (drag-and-drop on the web UI)
3. Repo → **Settings → Pages → Source: main branch → /(root) → Save**
4. Wait ~1 minute → visit `https://YOUR_USERNAME.github.io/REPO_NAME/`

### Netlify (drag-and-drop, 30 seconds)
1. Go to <https://app.netlify.com/drop>
2. Drag the folder containing `index.html` onto the page
3. Done — you get a public HTTPS URL instantly (required for camera on iOS)

### Cloudflare Pages, Vercel, Surge.sh
All work the same way — upload the folder, get an HTTPS URL.

## How it works

```
getUserMedia (back camera, 720p)
   ↓
<video> element (hidden, just a frame source)
   ↓
TensorFlow.js + COCO-SSD model.detect(video)
   ↓ every ~60ms
[ { class, score, bbox: [x, y, w, h] }, ... ]
   ↓
Canvas overlay draws colored borders + label pills
   ↓
Tap on canvas → coordinate mapped to video pixel space
   ↓
Find detection whose bbox contains the tap → show object card
```

The COCO-SSD model (`lite_mobilenet_v2` variant) is ~7 MB and loads once from the jsDelivr CDN. After the first load, your browser caches it.

## Customization

| Change | Where in `index.html` |
|---|---|
| Confidence threshold (currently 0.5) | `model.detect(video, 10, 0.5)` |
| Max detections (currently 10) | `model.detect(video, 10, 0.5)` |
| Category colors | `CATEGORIES` object |
| Italian label for a class | `IT_LABELS` object |
| UI strings | `STRINGS` object |
| Detection frame rate | `setTimeout(() => requestAnimationFrame(detectLoop), 60)` — lower number = faster |
| Camera resolution | `width: { ideal: 1280 }` in `getUserMedia` |

## Troubleshooting

**Black screen / no camera on iPhone Safari**
- iOS requires HTTPS (or localhost) for camera access. Use the local server method above, or deploy to Netlify/GitHub Pages.
- Settings → Safari → Camera → set to "Allow" or "Ask"

**"Loading AI model…" never finishes**
- Check internet connection — the model downloads from a CDN on first load (~7 MB)
- Try a different browser

**No boxes appearing**
- COCO-SSD only detects the 80 COCO classes. Common objects not in the list (e.g. pens, keys, plants beyond "potted plant") won't be detected.
- Try pointing at: a person, a phone, a cup, a laptop, a bottle, a chair, a book

**Slow performance on older iPhones**
- Edit `index.html` → change `base: "lite_mobilenet_v2"` to `base: "mobilenet_v1"` (faster but slightly less accurate)

## License

MIT — do whatever you want.
